package org.example;
/*********************************************************
 * nazwa funkcji: User
 *     * parametry wejściowe: na dole napisane
 *         * wartość zwracana: nic
 *             * autor: Olaf Karaś*
 * ****************************************************/
public class User {
      String Name;

      public User(String name, String surname, int age, int securityNumber, double money, String date, int ageofanaccount, String country) {
            Name = name;
            Surname = surname;
            Age = age;
            SecurityNumber = securityNumber;
            Money = money;
            this.date = date;
            Ageofanaccount = ageofanaccount;
            Country = country;
      }

      String Surname;
      int Age;
      int SecurityNumber;
      double Money;
      String date;
      int Ageofanaccount;
      String Country;

}

