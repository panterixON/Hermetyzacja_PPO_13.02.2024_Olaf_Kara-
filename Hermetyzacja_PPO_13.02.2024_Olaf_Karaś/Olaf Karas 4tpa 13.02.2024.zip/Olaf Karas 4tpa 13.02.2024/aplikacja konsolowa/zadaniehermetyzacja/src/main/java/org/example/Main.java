package org.example;

/*********************************************************
 * nazwa funkcji: Funkcji printujaca
 *     * parametry wejściowe: User przechowuje dane Usera CEO dane CEO i Currenc nazwy walut>
 *         * wartość zwracana: wartości
 *             * autor: Olaf Karaś*
 * ****************************************************/
public class Main {
    public static void main(String[] args) {
        User p1 = new User("Kamil","Slimak",44,1234567890,3400.2,"21.06.1979",4,"Poland");
        User p2 = new User("Jan","Abacki",21,1234567890,6900,"21.12.2003",3,"Poland");
        User p3 = new User("Kuba","Rozpruwacz",30,1234567890,1111,"21.07.1996",7,"Poland");

        CEO ceo1 = new CEO("Kamil","Ślimak",60,4000,3,"21.06.1963","France","ceo3");
        CEO ceo2 = new CEO("Jan","Abacki",45,5000,4,"21.12.1978","Ukraina","ceo2");
        CEO ceo3 = new CEO("Kuba","Rozpruwacz",38,6000,5,"21.07.1886","Bulgaria","ceo1");

        Currenc c1 = new Currenc("PLN","EUR","USD","CHF","GBP","JPY","AUD","CNY");
        Currenc c2 = new Currenc("PLN","EUR","USD","CHF","GBP","JPY","AUD","CNY");
        Currenc c3 = new Currenc("PLN","EUR","USD","CHF","GBP","JPY","AUD","CNY");

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
        System.out.println(ceo1);
        System.out.println(ceo2);
        System.out.println(ceo3);
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);


    }

}
