package org.example;
/*********************************************************
 * nazwa funkcji: CEO
 *     * parametry wejściowe: podane na dole
 *         * wartość zwracana: nic
 *             * autor: Olaf Karaś*
 * ****************************************************/
public class CEO {
  String Name;
  String Surname;
  int Age;
  double Earnings;
  int Level;
  String birth_year;
  String Country;
  String position;

    public CEO(String name, String surname, int age, double earnings, int level, String birth_year, String country, String position) {
        Name = name;
        Surname = surname;
        Age = age;
        Earnings = earnings;
        Level = level;
        this.birth_year = birth_year;
        Country = country;
        this.position = position;
    }
}
