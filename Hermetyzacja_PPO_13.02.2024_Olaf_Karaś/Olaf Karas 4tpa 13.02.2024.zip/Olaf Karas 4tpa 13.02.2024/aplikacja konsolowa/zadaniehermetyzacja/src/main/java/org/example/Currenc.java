package org.example;
/*********************************************************
 * nazwa funkcji: Currenc
 *     * parametry wejściowe: na dole napisane
 *         * wartość zwracana: nic
 *             * autor: Olaf Karaś*
 * ****************************************************/
public class Currenc {
    String PLN;
    String EUR;
    String USD;
    String CHF;
    String GBP;
    String JPY;
    String AUD;
    String CNY;

    public Currenc(String PLN, String EUR, String USD, String CHF, String GBP, String JPY, String AUD, String CNY) {
        this.PLN = PLN;
        this.EUR = EUR;
        this.USD = USD;
        this.CHF = CHF;
        this.GBP = GBP;
        this.JPY = JPY;
        this.AUD = AUD;
        this.CNY = CNY;
    }
}
